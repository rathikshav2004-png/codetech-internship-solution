package com.codtech.internship.task3;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/** Simple multithreaded chat server with broadcast and join/leave notifications. */
public class ChatServer {

    private final int port;
    private final Set<ClientHandler> clients = ConcurrentHashMap.newKeySet();

    public ChatServer(int port) {
        this.port = port;
    }

    public void start() throws IOException {
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Chat server started on port " + port);
            while (true) {
                Socket socket = serverSocket.accept();
                ClientHandler handler = new ClientHandler(socket);
                clients.add(handler);
                new Thread(handler).start();
            }
        }
    }

    private void broadcast(String message, ClientHandler exclude) {
        for (ClientHandler c : clients) {
            if (c != exclude) {
                c.send(message);
            }
        }
    }

    private class ClientHandler implements Runnable {
        private final Socket socket;
        private PrintWriter out;
        private BufferedReader in;
        private String username = "anonymous";

        ClientHandler(Socket socket) {
            this.socket = socket;
        }

        void send(String msg) {
            if (out != null) out.println(msg);
        }

        @Override
        public void run() {
            try (socket) {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);

                // First message must be the username
                out.println("Enter your username:");
                String name = in.readLine();
                if (name != null && !name.isBlank()) {
                    username = name.trim();
                }
                out.println("Welcome, " + username + "! Type messages; '/quit' to exit.");
                broadcast("*** " + username + " joined the chat ***", this);
                System.out.println(username + " connected.");

                String line;
                while ((line = in.readLine()) != null) {
                    if (line.equalsIgnoreCase("/quit")) {
                        break;
                    }
                    String full = "[" + username + "]: " + line;
                    System.out.println(full);
                    broadcast(full, this);
                }
            } catch (IOException e) {
                System.err.println("Client error: " + e.getMessage());
            } finally {
                clients.remove(this);
                broadcast("*** " + username + " left the chat ***", this);
                System.out.println(username + " disconnected.");
            }
        }
    }

    public static void main(String[] args) throws IOException {
        int port = args.length > 0 ? Integer.parseInt(args[0]) : 5555;
        new ChatServer(port).start();
    }
}