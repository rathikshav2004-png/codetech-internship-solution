package com.codtech.internship.task3;

import java.io.*;
import java.net.Socket;

/** Simple chat client. Usage: ChatClient <host> <port> <username> */
public class ChatClient {

    public static void main(String[] args) throws IOException {
        String host = args.length > 0 ? args[0] : "localhost";
        int port = args.length > 1 ? Integer.parseInt(args[1]) : 5555;
        String username = args.length > 2 ? args[2] : "user";

        try (Socket socket = new Socket(host, port)) {
            BufferedReader serverIn = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter serverOut = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
            BufferedReader console = new BufferedReader(new InputStreamReader(System.in));

            // Send username (server will prompt but we proactively send it to match UX)
            // Read initial server line (prompt), then send username
            String prompt = serverIn.readLine();
            if (prompt != null) System.out.println(prompt);
            serverOut.println(username);

            // Reader thread for server messages
            Thread reader = new Thread(() -> {
                try {
                    String line;
                    while ((line = serverIn.readLine()) != null) {
                        System.out.println(line);
                    }
                } catch (IOException ignored) {}
            });
            reader.setDaemon(true);
            reader.start();

            System.out.println("You can start chatting. Type /quit to exit.");
            String input;
            while ((input = console.readLine()) != null) {
                serverOut.println(input);
                if ("/quit".equalsIgnoreCase(input.trim())) break;
            }
        }
    }
}