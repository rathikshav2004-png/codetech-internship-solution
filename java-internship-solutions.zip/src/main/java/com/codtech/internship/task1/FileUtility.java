package com.codtech.internship.task1;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * FileUtility - a small utility for common text file operations.
 * Methods are static and throw IOException so callers can handle errors cleanly.
 */
public class FileUtility {

    /** Write lines to a file. If append is false, the file is created or truncated. */
    public static void writeLines(Path path, List<String> lines, boolean append) throws IOException {
        if (append) {
            Files.write(path, lines, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } else {
            Files.write(path, lines, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        }
    }

    /** Write a single string (with newline) to a file. */
    public static void writeString(Path path, String content, boolean append) throws IOException {
        writeLines(path, List.of(content + System.lineSeparator()), append);
    }

    /** Read all lines. */
    public static List<String> readAllLines(Path path) throws IOException {
        return Files.readAllLines(path, StandardCharsets.UTF_8);
    }

    /** Read the entire file content as one string (joined by newlines). */
    public static String readAll(Path path) throws IOException {
        return String.join(System.lineSeparator(), readAllLines(path));
    }

    /** Replace all occurrences of 'find' with 'replace' in the file. */
    public static void replaceAll(Path path, String find, String replace) throws IOException {
        List<String> lines = readAllLines(path);
        List<String> replaced = lines.stream()
                .map(l -> l.replace(find, replace))
                .collect(Collectors.toList());
        writeLines(path, replaced, false);
    }

    /** Replace (overwrite) a specific 1-based line number with new content. */
    public static void replaceLine(Path path, int lineNumber1Based, String newContent) throws IOException {
        List<String> lines = new ArrayList<>(readAllLines(path));
        if (lineNumber1Based < 1 || lineNumber1Based > lines.size()) {
            throw new IllegalArgumentException("Line number out of range.");
        }
        lines.set(lineNumber1Based - 1, newContent);
        writeLines(path, lines, false);
    }

    /** Delete any line that contains the given keyword (case-sensitive). */
    public static void deleteLinesContaining(Path path, String keyword) throws IOException {
        List<String> lines = readAllLines(path).stream()
                .filter(l -> !l.contains(keyword))
                .collect(Collectors.toList());
        writeLines(path, lines, false);
    }
}