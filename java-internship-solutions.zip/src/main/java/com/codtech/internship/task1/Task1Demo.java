package com.codtech.internship.task1;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

/** Demonstrates Task 1 file operations with clear console logs. */
public class Task1Demo {

    public static void main(String[] args) throws IOException {
        Path file = Path.of("sample.txt");

        // 1) Create and write
        List<String> content = Arrays.asList(
                "Hello, CODTECH!",
                "This is the first version of the file.",
                "We will modify this file step by step."
        );
        FileUtility.writeLines(file, content, false);
        System.out.println("Created 'sample.txt' with initial content.\n");

        // 2) Read
        System.out.println("== Read All ==");
        System.out.println(FileUtility.readAll(file));
        System.out.println();

        // 3) Append
        FileUtility.writeString(file, "Appending one more line.", true);
        System.out.println("Appended a line.\n");

        // 4) Replace all
        FileUtility.replaceAll(file, "file", "document");
        System.out.println("Replaced all occurrences of 'file' with 'document'.\n");

        // 5) Replace specific line (1-based)
        FileUtility.replaceLine(file, 2, "This is the UPDATED second line.");
        System.out.println("Replaced line 2 with updated content.\n");

        // 6) Delete lines containing a keyword
        FileUtility.deleteLinesContaining(file, "Appending");
        System.out.println("Deleted any lines containing 'Appending'.\n");

        // Final output
        System.out.println("== Final Content ==");
        System.out.println(FileUtility.readAll(file));
        System.out.println("\nDemo complete. Check 'sample.txt'.");
    }
}