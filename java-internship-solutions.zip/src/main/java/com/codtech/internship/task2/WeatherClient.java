package com.codtech.internship.task2;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.OffsetDateTime;
import java.util.Optional;

/** Calls Open-Meteo weather API to get current weather for a lat/lon. */
public class WeatherClient {

    public static class CurrentWeather {
        public final double temperatureC;
        public final double windspeedKmh;
        public final double winddirectionDeg;
        public final OffsetDateTime time;

        public CurrentWeather(double temperatureC, double windspeedKmh, double winddirectionDeg, OffsetDateTime time) {
            this.temperatureC = temperatureC;
            this.windspeedKmh = windspeedKmh;
            this.winddirectionDeg = winddirectionDeg;
            this.time = time;
        }
    }

    public static Optional<CurrentWeather> getCurrent(double lat, double lon) throws IOException, InterruptedException {
        HttpClient client = HttpClient.newHttpClient();
        String url = String.format("https://api.open-meteo.com/v1/forecast?latitude=%f&longitude=%f&current_weather=true", lat, lon);
        HttpRequest req = HttpRequest.newBuilder().uri(URI.create(url)).GET().build();
        HttpResponse<String> resp = client.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() != 200) return Optional.empty();

        JsonObject root = JsonParser.parseString(resp.body()).getAsJsonObject();
        if (!root.has("current_weather")) return Optional.empty();
        JsonObject cw = root.getAsJsonObject("current_weather");

        double temp = cw.get("temperature").getAsDouble();
        double wind = cw.get("windspeed").getAsDouble();
        double dir = cw.get("winddirection").getAsDouble();
        String timeStr = cw.get("time").getAsString();

        return Optional.of(new CurrentWeather(temp, wind, dir, OffsetDateTime.parse(timeStr)));
    }
}