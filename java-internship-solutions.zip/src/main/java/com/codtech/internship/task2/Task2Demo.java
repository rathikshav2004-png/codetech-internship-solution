package com.codtech.internship.task2;

import java.util.Optional;

/** Demonstrates Task 2: Fetch current weather for a city and print structured output. */
public class Task2Demo {
    public static void main(String[] args) throws Exception {
        String city = args.length > 0 ? String.join(" ", args) : "Bengaluru";

        System.out.println("[Task 2] Weather for city: " + city);

        Optional<GeoLocation> locOpt = GeoLocation.geocodeCity(city);
        if (locOpt.isEmpty()) {
            System.out.println("Could not geocode the city name. Try a different one.");
            return;
        }
        GeoLocation loc = locOpt.get();
        System.out.printf("Resolved to: %s (lat=%.4f, lon=%.4f)%n", loc.name, loc.latitude, loc.longitude);

        Optional<WeatherClient.CurrentWeather> cwOpt = WeatherClient.getCurrent(loc.latitude, loc.longitude);
        if (cwOpt.isEmpty()) {
            System.out.println("Could not fetch current weather. Try again later.");
            return;
        }
        WeatherClient.CurrentWeather cw = cwOpt.get();

        System.out.println("---- CURRENT WEATHER ----");
        System.out.printf("Time (UTC): %s%n", cw.time);
        System.out.printf("Temperature: %.1f °C%n", cw.temperatureC);
        System.out.printf("Wind: %.1f km/h @ %.0f°%n", cw.windspeedKmh, cw.winddirectionDeg);
    }
}