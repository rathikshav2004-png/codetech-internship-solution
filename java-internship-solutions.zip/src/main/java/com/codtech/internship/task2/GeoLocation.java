package com.codtech.internship.task2;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.Optional;

/** Simple geocoder using Open-Meteo geocoding API (no API key required). */
public class GeoLocation {
    public final String name;
    public final double latitude;
    public final double longitude;

    public GeoLocation(String name, double latitude, double longitude) {
        this.name = name;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public static Optional<GeoLocation> geocodeCity(String city) throws IOException, InterruptedException {
        HttpClient client = HttpClient.newHttpClient();
        String url = "https://geocoding-api.open-meteo.com/v1/search?count=1&name=" + 
                java.net.URLEncoder.encode(city, StandardCharsets.UTF_8);
        HttpRequest request = HttpRequest.newBuilder().uri(URI.create(url)).GET().build();
        HttpResponse<String> resp = client.send(request, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() != 200) return Optional.empty();

        JsonObject root = JsonParser.parseString(resp.body()).getAsJsonObject();
        JsonArray results = root.has("results") && root.get("results").isJsonArray() ? root.getAsJsonArray("results") : null;
        if (results == null || results.size() == 0) return Optional.empty();
        JsonObject first = results.get(0).getAsJsonObject();
        String name = first.get("name").getAsString();
        double lat = first.get("latitude").getAsDouble();
        double lon = first.get("longitude").getAsDouble();
        return Optional.of(new GeoLocation(name, lat, lon));
    }
}