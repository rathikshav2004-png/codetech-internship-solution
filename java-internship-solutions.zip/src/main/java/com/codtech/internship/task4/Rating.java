package com.codtech.internship.task4;

public class Rating {
    public final int userId;
    public final String itemId;
    public final double rating;

    public Rating(int userId, String itemId, double rating) {
        this.userId = userId;
        this.itemId = itemId;
        this.rating = rating;
    }
}