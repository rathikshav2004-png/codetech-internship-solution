package com.codtech.internship.task4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;

public class DataModel {
    // userId -> (itemId -> rating)
    public final Map<Integer, Map<String, Double>> userItem = new HashMap<>();
    // itemId -> (userId -> rating)
    public final Map<String, Map<Integer, Double>> itemUser = new HashMap<>();

    public void loadFromCsv(String resourcePath) throws IOException {
        InputStream in = DataModel.class.getResourceAsStream(resourcePath);
        if (in == null) throw new IOException("Resource not found: " + resourcePath);

        try (BufferedReader br = new BufferedReader(new InputStreamReader(in))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                String[] parts = line.split(",");
                int userId = Integer.parseInt(parts[0].trim());
                String itemId = parts[1].trim();
                double rating = Double.parseDouble(parts[2].trim());
                addRating(new Rating(userId, itemId, rating));
            }
        }
    }

    public void addRating(Rating r) {
        userItem.computeIfAbsent(r.userId, k -> new HashMap<>()).put(r.itemId, r.rating);
        itemUser.computeIfAbsent(r.itemId, k -> new HashMap<>()).put(r.userId, r.rating);
    }

    public Set<String> getItems() { return itemUser.keySet(); }
    public Set<Integer> getUsers() { return userItem.keySet(); }
}