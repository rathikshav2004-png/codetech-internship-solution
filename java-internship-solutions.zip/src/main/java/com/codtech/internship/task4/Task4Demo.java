package com.codtech.internship.task4;

import java.util.List;
import java.util.Map;

public class Task4Demo {
    public static void main(String[] args) throws Exception {
        int userId = args.length > 0 ? Integer.parseInt(args[0]) : 1;
        int topN = args.length > 1 ? Integer.parseInt(args[1]) : 5;

        DataModel data = new DataModel();
        data.loadFromCsv("/data/ratings.csv");

        ItemBasedRecommender rec = new ItemBasedRecommender(data);
        List<Map.Entry<String, Double>> results = rec.recommendTopN(userId, topN);

        System.out.printf("Top %d recommendations for user %d:%n", topN, userId);
        if (results.isEmpty()) {
            System.out.println("(No recommendations could be generated.)");
        } else {
            int rank = 1;
            for (Map.Entry<String, Double> e : results) {
                System.out.printf("%d) %s -> predicted score %.3f%n", rank++, e.getKey(), e.getValue());
            }
        }
    }
}