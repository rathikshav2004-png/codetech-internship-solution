package com.codtech.internship.task4;

import java.util.*;
import java.util.stream.Collectors;

/** Minimal item-based collaborative filtering recommender (cosine similarity). */
public class ItemBasedRecommender {

    private final DataModel data;

    public ItemBasedRecommender(DataModel data) {
        this.data = data;
    }

    /** Cosine similarity between two items over common users. */
    private double cosine(String itemA, String itemB) {
        Map<Integer, Double> a = data.itemUser.getOrDefault(itemA, Map.of());
        Map<Integer, Double> b = data.itemUser.getOrDefault(itemB, Map.of());

        double dot = 0.0, na = 0.0, nb = 0.0;
        for (Map.Entry<Integer, Double> e : a.entrySet()) {
            int u = e.getKey();
            double ra = e.getValue();
            if (b.containsKey(u)) {
                double rb = b.get(u);
                dot += ra * rb;
            }
            na += ra * ra;
        }
        for (double rb : b.values()) nb += rb * rb;

        if (na == 0 || nb == 0) return 0.0;
        return dot / (Math.sqrt(na) * Math.sqrt(nb));
    }

    /** Predict score for user u on item i using weighted sum of their rated items. */
    public double predict(int userId, String itemId) {
        Map<String, Double> rated = data.userItem.getOrDefault(userId, Map.of());
        if (rated.isEmpty()) return 0.0;

        double num = 0.0, den = 0.0;
        for (Map.Entry<String, Double> e : rated.entrySet()) {
            String j = e.getKey();
            double ruj = e.getValue();
            if (j.equals(itemId)) continue;
            double sim = cosine(itemId, j);
            if (sim == 0) continue;
            num += sim * ruj;
            den += Math.abs(sim);
        }
        return den == 0 ? 0.0 : num / den;
    }

    /** Recommend Top-N items not yet rated by the user. */
    public List<Map.Entry<String, Double>> recommendTopN(int userId, int n) {
        Map<String, Double> rated = data.userItem.getOrDefault(userId, Map.of());
        Set<String> candidates = new HashSet<>(data.getItems());
        candidates.removeAll(rated.keySet());

        Map<String, Double> scores = new HashMap<>();
        for (String item : candidates) {
            scores.put(item, predict(userId, item));
        }
        return scores.entrySet().stream()
                .sorted(Map.Entry.<String, Double>comparingByValue().reversed())
                .limit(n)
                .collect(Collectors.toList());
    }
}