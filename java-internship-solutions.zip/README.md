# CODTECH Java Internship – Complete Solutions

This project contains **fully working, well‑commented solutions** for the four tasks in your internship PDF:

1. **Task 1 – File Handling Utility (read / write / modify text files)**  
2. **Task 2 – REST API Client (Weather example using Open‑Meteo)**  
3. **Task 3 – Multithreaded Chat (Java sockets + threads)**  
4. **Task 4 – Recommendation System (Item‑based CF in pure Java)**  

> Java 17 + Maven are assumed.

---

## How to Build

```bash
mvn -v           # verify Maven install
mvn clean package
```

The build produces `target/java-internship-solutions-1.0.0-jar-with-dependencies.jar`.

---

## Task 1 – File Handling Utility

Run the demo (creates and modifies `sample.txt` in the project folder):

```bash
java -cp target/java-internship-solutions-1.0.0-jar-with-dependencies.jar com.codtech.internship.task1.Task1Demo
```

Key features:
- Create/write a file
- Read entire file / read all lines
- Append
- Replace all occurrences
- Replace a specific line by line number (1-based)
- Delete lines containing a keyword

---

## Task 2 – REST API Client (Weather)

Fetches **current weather** for a city using Open‑Meteo APIs (no API key required).

```bash
# Example with default (Bengaluru):
java -cp target/java-internship-solutions-1.0.0-jar-with-dependencies.jar com.codtech.internship.task2.Task2Demo

# Specify a city:
java -cp target/java-internship-solutions-1.0.0-jar-with-dependencies.jar com.codtech.internship.task2.Task2Demo Mumbai
```

What it does:
- Geocodes the city name to lat/lon
- Calls the weather forecast endpoint for **current_weather**
- Parses JSON using Gson
- Prints a structured summary

---

## Task 3 – Multithreaded Chat (Sockets)

Start the server (default port **5555**):
```bash
java -cp target/java-internship-solutions-1.0.0-jar-with-dependencies.jar com.codtech.internship.task3.ChatServer 5555
```

Start multiple clients (each in its own terminal):
```bash
# Client takes: host port username
java -cp target/java-internship-solutions-1.0.0-jar-with-dependencies.jar com.codtech.internship.task3.ChatClient localhost 5555 Alice
java -cp target/java-internship-solutions-1.0.0-jar-with-dependencies.jar com.codtech.internship.task3.ChatClient localhost 5555 Bob
```
Type messages and press Enter. Type `/quit` to disconnect.

Features:
- Thread-per-client, safe broadcast
- Usernames with join/leave notices
- Graceful shutdown

---

## Task 4 – Recommendation System (Item‑Based CF)

A compact, dependency‑free **item‑based collaborative filtering** recommender with a small sample dataset at `src/main/resources/data/ratings.csv`.

Run the demo:
```bash
# Optional args: <userId> <topN>
java -cp target/java-internship-solutions-1.0.0-jar-with-dependencies.jar com.codtech.internship.task4.Task4Demo 1 5
```

What it does:
- Loads user‑item ratings from CSV
- Computes cosine similarity between items (over common raters)
- Predicts scores for items a user hasn’t rated
- Prints **Top‑N** recommendations

---

## Notes
- All code has inline comments and clear structure for GitHub.
- You can change the assembly plugin’s `mainClass` if you want an executable fat‑JAR for another task.
- For learning purposes the recommender is implemented from scratch; in real projects you could use libraries *like* Apache Mahout.